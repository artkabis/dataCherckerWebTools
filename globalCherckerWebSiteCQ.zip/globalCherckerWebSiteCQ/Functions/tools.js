import CheckerImg from './CheckerImg';
import {Test} from './test.js';
console.log('tools.js loaded successfully');
console.log('checker ESM : ',{CheckerImg});
console.log('Test ESM : ',{Test});