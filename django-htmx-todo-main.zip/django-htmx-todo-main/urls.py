from django.contrib import admin
from django.urls import include, path
from django.contrib.auth import views 
from chat.views import chat_view  

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.index, name='index'),
    path('todo/', include('todo.urls')),
    path('chat/', include('chat.urls'), name='chat')
]

  