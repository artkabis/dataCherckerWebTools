from django.urls import path, include
from . import views
from django.urls import re_path

from . import consumers
# from .views import SSEView


app_name = 'chat'  # Définissez un nom d'espace pour l'application "chat"
# websocket_urlpatterns = [
#     re_path(r'ws/chat/(?P<room_name>\w+)/$', consumers.ChatConsumer.as_asgi()),
# ]
urlpatterns = [
    path('rooms/', views.room_list, name='room_list'),
    path('create/', views.create_room, name='create_room'),  # Ajoutez cette ligne
    path('<str:room>/', views.chat_view, name='chat_view'),
    path('edit_room/<int:room_id>/', views.edit_room, name='edit_room'),
    path('delete_room/<int:room_id>/', views.delete_room, name='delete_room'),
    path('send_message/', views.send_message, name='send_message'),
    path('delete_message/<int:message_id>/', views.delete_message, name='delete_message'),
    path('load_messages/', views.load_messages, name='load_messages'),
    path('get_last_message_id/<str:room_name>/', views.get_last_message_id, name='get_last_message_id'),
]


