from django import forms
from .models import Message
from .models import Room
from django.contrib.auth.models import User


class MessageForm(forms.ModelForm):
    class Meta:
        model = Message
        fields = ['content', 'room']


class RoomCreationForm(forms.Form):
    name = forms.CharField(max_length=100, label='Nom de la Room')

class RoomForm(forms.ModelForm):
        members = forms.ModelMultipleChoiceField(
        queryset=User.objects.all(),
        widget=forms.SelectMultiple(attrs={'class': 'select2'})
    )
        class Meta:
            model = Room
            fields = ['name']  # Ajoutez d'autres champs de salle au besoin

class AddUserToRoomForm(forms.Form):
    username = forms.ModelChoiceField(
        label='Utilisateur',
        queryset=User.objects.all(),
        widget=forms.Select(attrs={'class': 'selectUser'})  # Utilisez un widget Select2 pour l'auto-complétion
    )