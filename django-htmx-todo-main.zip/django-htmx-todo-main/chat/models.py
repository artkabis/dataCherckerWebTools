from django.db import models
from django.contrib.auth.models import User

from django.db import models
from django.contrib.auth.models import User

class Room(models.Model):
    name = models.CharField(max_length=255, unique=True)
    # access = models.OneToOneField('RoomAccess', on_delete=models.CASCADE, null=True, blank=True, related_name='room_relation')
    users = models.ManyToManyField(User)
    def __str__(self):
        return self.name

class RoomAccess(models.Model):
    room = models.OneToOneField(Room, on_delete=models.CASCADE, related_name='access')
    creator = models.ForeignKey(User, on_delete=models.CASCADE, related_name='room_creator')
    allowed_users = models.ManyToManyField(User, related_name='allowed_rooms')


    def add_allowed_user(self, user):
        self.allowed_users.add(user)

    def remove_allowed_user(self, user):
        self.allowed_users.remove(user)
    
    def is_user_allowed(self, user):
        allowed = user == self.creator or user in self.allowed_users.all()
        print(f'user autorisé : {allowed}  ') 
        return allowed

class Message(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    content = models.TextField()
    room = models.ForeignKey(Room, on_delete=models.CASCADE)
    timestamp = models.DateTimeField(auto_now_add=True)

    def is_author(self, user):
        return self.user == user

class ChatMessage(models.Model):
    room_name = models.CharField(max_length=255)
    message = models.TextField()
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    timestamp = models.DateTimeField(auto_now_add=True)



