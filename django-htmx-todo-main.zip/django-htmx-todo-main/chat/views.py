from django.shortcuts import render, redirect, get_object_or_404
from django.http import Http404
from django.db import transaction
from django.http import JsonResponse
from django.contrib.auth.decorators import login_required
from .models import Room, Message
from .forms import RoomCreationForm
from django.urls import reverse
from django.http import HttpResponseRedirect
from django.views.decorators.http import require_http_methods
from django.template.loader import render_to_string
import json
from .models import RoomAccess
from .models import Room, Message
from .forms import RoomCreationForm
from .forms import AddUserToRoomForm  
from django.contrib.auth.models import User




def is_ajax(request):
    return request.META.get('HTTP_X_REQUESTED_WITH') == 'XMLHttpRequest'

from django.shortcuts import render, redirect, get_object_or_404
from django.http import Http404
from django.db import transaction
from django.http import JsonResponse
from django.contrib.auth.decorators import login_required
from .models import Room, Message
from .forms import RoomCreationForm
from django.urls import reverse
from django.http import HttpResponseRedirect
from django.views.decorators.http import require_http_methods
from django.template.loader import render_to_string
import json
from .models import RoomAccess
from .models import Room, Message
from .forms import RoomCreationForm
from .forms import AddUserToRoomForm  
from django.contrib.auth.models import User
from django.http import HttpResponse



def is_ajax(request):
    return request.META.get('HTTP_X_REQUESTED_WITH') == 'XMLHttpRequest'


    
def chat_view(request, room=None):
    current_user = request.user
    rooms = Room.objects.all()
    users = User.objects.all()
    notification = ""
    user_just_added = None  # Initialisez la variable à None par défaut
    context = {}  # Initialisez context en dehors du bloc if

    if room:
        current_room = get_object_or_404(Room, name=room)

        if not current_room.access.is_user_allowed(current_user):
            # raise Http404("Vous n'avez pas l'autorisation d'accéder à cette room.")
            return render(request, 'chat/no_acccess_autorisation.html', context)

        messages = Message.objects.filter(room=current_room).order_by('timestamp')
        room_name = current_room.name

        if request.method == 'POST':
            user_to_add = request.POST.get('user_to_add')
            if user_to_add:
                try:
                    user = User.objects.get(username=user_to_add)
                    current_room.access.add_allowed_user(user)
                    user_just_added = user  # Mettez l'utilisateur ajouté dans la variable
                    notification = f"{user.username} est désormais autorisé dans la salle {current_room.name}."
                except User.DoesNotExist:
                    notification = f"L'utilisateur {user_to_add} n'existe pas."

            message_content = request.POST.get('message')
            if message_content and current_room:
                Message.objects.create(
                    user=current_user,
                    content=message_content,
                    room=current_room
                )

            # Mettez à jour la variable context ici
            context.update({
                'room': room_name,
                'messages': messages,
                'notification': notification,
                'user_just_added': user_just_added,  # Ajoutez la variable dans le contexte
            })

            # Après avoir effectué les opérations, renvoyez le contenu du message de notification
            user_notification_html = render_to_string('chat/user_notification.html', context)

            # Renvoyez simplement le contenu du message de notification sans objet JSON
            return HttpResponse(user_notification_html)


        context = {
            'room': room_name,
            'messages': messages,
            'rooms': rooms,
            'notification': notification,
            'users': users,
            'user_just_added': user_just_added,  # Ajoutez la variable dans le contexte
        }

    return render(request, 'chat/chat.html', context)


def delete_message(request, message_id):
    message = get_object_or_404(Message, id=message_id)
    
    # Vérifiez si l'utilisateur actuel est l'auteur du message
    if message.is_author(request.user):
        message.delete()
        return JsonResponse({'status': 'ok'})
    else:
        return JsonResponse({'status': 'error', 'message': 'Vous n\'êtes pas l\'auteur de ce message.'})

def send_message(request):
    response_data = {}
    if request.method == 'POST':
        current_user = request.user
        room_name = request.POST.get('room')  # Assurez-vous que le champ caché est nommé "room"
        current_room = get_object_or_404(Room, name=room_name)
        message_content = request.POST.get('message')

        if message_content:
            Message.objects.create(
                user=current_user,
                content=message_content,
                room=current_room
            )
            
            response_data['status'] = 'success'

    return JsonResponse(response_data)


def load_messages(request):
    # Votre logique pour charger les messages ici
    messages = []  # Remplacez ceci par la logique pour charger les messages
    
    # Formatez les messages en JSON
    message_data = []
    for message in messages:
        message_data.append({
            'user': message.user.username,
            'timestamp': message.timestamp.strftime('%Y-%m-%d %H:%M:%S'),
            'content': message.content,
        })
    
    return JsonResponse({'messages': message_data})

def check_new_messages(request, room_name, last_message_id):
    # Recherchez le dernier message dans la base de données pour la room donnée
    last_message = Message.objects.filter(room=room_name).order_by('-id').first()

    if last_message and last_message.id != int(last_message_id):
        # Il y a de nouveaux messages, renvoyez-les au format JSON
        new_messages = Message.objects.filter(room=room_name, id__gt=int(last_message_id))
        new_messages_data = [{'user': message.user.username, 'content': message.content} for message in new_messages]
        return JsonResponse(new_messages_data, safe=False)

    return JsonResponse([], safe=False)

def get_last_message(room_name):
    # Obtenez le dernier message pour cette salle de chat
    return Message.objects.filter(room__name=room_name).order_by('-timestamp').first()

@require_http_methods(["GET"])
def get_last_message_id(request, room_name):
    last_message = Message.objects.filter(room__name=room_name).order_by('-timestamp').first()
    if last_message:
        message_data = {
            'last_message_id': last_message.id,
            'last_message_content': last_message.content,
            'last_message_user': last_message.user.username,
            'last_message_timestamp': last_message.timestamp.strftime('%Y-%m-%d %H:%M:%S'),
        }
    else:
        message_data = {
            'last_message_id': 0,
            'last_message_content': '',
            'last_message_user': '',
            'last_message_timestamp': '',
        }

    return JsonResponse(message_data)


def get_new_messages(request, room_id):
    last_message_id = request.GET.get('last_message_id')
    data = [{"id":last_message_id, "roomId" : room_id}] 
    return JsonResponse({'messages': data})

def room_list(request):
    rooms = Room.objects.all()
    print(rooms)
    return render(request, 'chat/room_list.html', {'rooms': rooms})

@transaction.atomic
@login_required
def create_room(request):
    if request.method == 'POST':
        form = RoomCreationForm(request.POST)
        if form.is_valid():
            room_name = form.cleaned_data['name']
            print(f'__________room_name : {room_name}')
            # Vérifiez d'abord si la salle existe déjà
            if Room.objects.filter(name=room_name).exists():
                # Traitez le cas où la salle existe déjà, par exemple, affichez un message d'erreur.
                print('La room existe déjà')

            else:
                new_room = Room.objects.create(name=room_name)
                room_access, created = RoomAccess.objects.get_or_create(room=new_room, creator=request.user)
                new_room.access = room_access
                new_room.save()



                # Redirigez l'utilisateur vers la salle nouvellement créée
                return HttpResponseRedirect(reverse('chat:chat_view', args=[room_name]))
    else:
        form = RoomCreationForm()

    # Récupérez la liste de toutes les salles
    rooms = Room.objects.all()

    return render(request, 'chat/create_room.html', {'form': form, 'rooms': rooms})




@login_required
def edit_room(request, room_id):
    room = get_object_or_404(Room, id=room_id)

    if request.method == 'POST':
        room.name = request.POST.get('room_name')
        room.save()
   
    return redirect('chat_view', room=room.name)

@login_required
def delete_room(request, room_id):
    room = get_object_or_404(Room, id=room_id)
    room.delete()
   
    return redirect('chat_view', room='default_room')

