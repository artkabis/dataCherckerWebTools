from setuptools import setup, find_packages

setup(
    name='nom-de-votre-projet',
    version='0.1',
    packages=find_packages(),
    install_requires=[
        'asgiref==3.7.2',
        'certifi==2023.7.22',
        'charset-normalizer==3.2.0',
        'distlib==0.3.7',
        'Django==4.2.4',
        'django-cors-headers==4.2.0',
        'everapi==0.1.1',
        'filelock==3.12.4',
        'freecurrencyapi==0.1.0',
        'idna==3.4',
        'numpy==1.25.2',
        'pipenv==2023.9.8',
        'platformdirs==3.10.0',
        'pytz==2023.3.post1',
        'requests==2.31.0',
        'sqlparse==0.4.4',
        'typing_extensions==4.7.1',
        'tzdata==2023.3',
        'urllib3==2.0.4',
        'virtualenv==20.24.5',
    ],
    entry_points={
        'console_scripts': [
            # Définissez les scripts exécutables ici, par exemple :
            'mon_script=nom_de_votre_module:fonction_principale',
        ],
    },
    author='Votre Nom',
    author_email='votre@email.com',
    description='Description de votre projet',
    url='https://github.com/votre-utilisateur/votre-projet',
)