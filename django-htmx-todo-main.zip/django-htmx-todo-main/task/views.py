from django.contrib.auth import models
from django.http.response import HttpResponse
from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.contrib import messages, auth
from django.contrib.auth import authenticate
from django.contrib.auth import logout
from . models import Task, DatasRecord
from django.contrib.auth.decorators import login_required
import json
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from .models import DatasRecord
from django.utils import timezone
import pytz  
from urllib.parse import urlsplit
from django.urls import reverse



@login_required(login_url='task:login') 
def home(request):
    tasks = Task.objects.filter(user=request.user).order_by('-created_at')
    return render(request, 'base.html', {'tasks': tasks})


def add_todo(request):
    tasks = Task.objects.filter(user=request.user).order_by('-created_at')
    if request.method == "POST":
        task = request.POST['task']

        task = Task.objects.create(
            task=task,
            user=request.user
        )
        task.save()
    return render(request, 'components/tasks.html', {'tasks': tasks})


def delete_todo(request, id):
    todo = Task.objects.get(pk=id)
    print(todo)
    todo.delete()
    tasks = Task.objects.filter(user=request.user).order_by('-created_at')
    return render(request, 'components/tasks.html', {'tasks': tasks})


def mark_complete(request, id):
    task = Task.objects.get(pk=id)
    print(task)
    if request.method == "POST":
        if task.task_status == False:
            task.task_status = True
        else:
            task.task_status = False
    task.save()
    tasks = Task.objects.filter(user=request.user).order_by('-created_at')
    return render(request, 'components/tasks.html', {'tasks': tasks})


def register(request):
    if request.method == "POST":
        first_name = request.POST['first_name']
        last_name = request.POST['last_name']
        username = request.POST['username'].lower()
        email = request.POST['email']
        password = request.POST['password']
        confirm_password = request.POST['confirm_password']

        if password == confirm_password:
            if User.objects.filter(username=username).exists():
                messages.warning(request, 'Username already exists')
                return redirect('task:register')
            else:
                if User.objects.filter(email=email).exists():
                    messages.warning(request, 'Email already registered')
                    return redirect('task:register')

                else:
                    user = User.objects.create_user(
                        first_name=first_name,
                        last_name=last_name,
                        username=username,
                        email=email,
                        password=password,
                    )

                    # user.is_active = False
                    user.save()
                    return redirect(reverse('task:login'))
        else:
            messages.warning(request, "Password don't Match")
            return redirect(reverse('task:register'))

    return render(request, 'components/register.html')


def login(request):
    if request.method == "POST":
        username = request.POST['username'].lower()
        password = request.POST['password']

        user = auth.authenticate(request, username=username, password=password)
        if user is not None:
            auth.login(request, user)
            messages.success(request, "Login Success")
            return redirect('task:home')
        else:
            messages.warning(request, "Invalid Credentials")
            return redirect(reverse('task:login'))

    return render(request, 'components/login.html')


def logout_user(request):
    logout(request)
    messages.success(request, "You have been successfully logged out")
    return redirect(reverse('task:login'))


def check_user(request):
    if request.method == "POST":
        username = request.POST['username']
        if User.objects.filter(username=username).exists():
            return HttpResponse('<span id = "username-check" class="warning-text font-weight-bold lead small text-danger px-2">Username already exists.</span')
        else:
            return HttpResponse('<span id = "username-check" class="warning-text lead small font-weight-bold text-danger px-2">Username available.</span')


def email_check(request):
    if request.method == "POST":
        email = request.POST['email']
        if User.objects.filter(email=email).exists():
            return HttpResponse('<span id = "email-check" class="warning-text font-weight-bold lead small text-danger px-2">Email already exists.</span')
        else:
            return HttpResponse('<span id = "email-check" class="warning-text font-weight-bold lead small text-danger px-2">Email Not registered</span')
        




@csrf_exempt
def datasCheck(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            user_username = data[0]['user']
   
            print('___________user : %s' % user_username)
            print('___________datas url site : %s' % data[0]['datas']['url_site'])

            urlSite = data[0]['datas']['url_site']
            parsed_url = urlsplit(urlSite)

            # Obtenez l'URL de base
            base_url = parsed_url.scheme + "://" + parsed_url.netloc + parsed_url.path


            print('___________datas : %s' % base_url)

            parts = user_username.split("\\")

            # Obtenez la partie après le "\"
            username = parts[-1]  # Cela donnera "gnicolle"
            username = username.strip()

            # Ajoutez "@domaine.com"
            email = username + "@solocal.com"
            
            # Vérifiez si un utilisateur avec ce nom d'utilisateur existe
            # try:
            #     user = User.objects.get(username=user_username)
            # except User.DoesNotExist:
            #     return JsonResponse({'message': f"L'utilisateur '{user_username}' n'existe pas."}, status=400)
            users_with_email = User.objects.filter(email=email)

            # Vérifiez si des utilisateurs ont été trouvés
            if users_with_email.exists():
                print('adresse e-mail existe dans la base de données.%s' % email)
                print('email in accound : %s' % email)
                # Si vous voulez obtenir le premier utilisateur trouvé, vous pouvez utiliser : user = users_with_email.first()
            else:
                print("L'adresse e-mail n'existe pas dans la base de données.")
            
            
            datas = data[0]['datas']
            # # Créez un identifiant unique
            # id_unique = 1  # Initialisez l'identifiant unique à 1
            # for data_item in datas:
            #     data_item["id"] = id_unique
            #     id_unique += 1  # Incrémentez l'identifiant unique pour le prochain objet JSON


            paris_timezone = pytz.timezone('Europe/Paris')
            formatted_timestamp = timezone.now().astimezone(paris_timezone)

            
            # Enregistrez les données dans la base de données
            record = DatasRecord(user = users_with_email.first(),timestamp=formatted_timestamp, name=username,email=email, datas=[datas],url_site=base_url)
            record.save()

            response_data = {'message': 'Le traitement est terminé côté Python', 'data': data}
            return JsonResponse(response_data)
        except json.JSONDecodeError:
            return JsonResponse({'message': 'Erreur lors du décodage JSON.'}, status=400)
    
    elif request.method == 'GET':
        # Gérez ici la requête GET pour interroger la base de données et afficher les données
        email = request.user.email  # Vous pouvez obtenir l'adresse e-mail de l'utilisateur connecté de cette manière
        print(email)
        data_records = DatasRecord.objects.filter(email=email)
        data_records = data_records.order_by('-timestamp')

        # Autres traitements...
        # Obtenez la valeur du champ de recherche url_site
        url_site_query = request.GET.get('url_site')
        # date_site_query = request.GET.get('timestamp')
        if url_site_query:
            data_records = data_records.filter(url_site__icontains=url_site_query)
        # if date_site_query:
            # data_records = data_records.filter(timestamp_icontains=date_site_query)
        # Retournez les données dans le modèle de la page HTML
        return render(request, 'components/datasCheck.html', {'data_records': data_records})



def ajax_search(request):
    query = request.GET.get('query', '')

    # Effectuez une recherche basée sur la similitude des caractères dans l'URL du site
    results = DatasRecord.objects.filter(url_site__icontains=query)

    # Générez le HTML des résultats (par exemple, sous forme de liste)
    results_html = ''
    for result in results:
        results_html += f'<li>{result.url_site}</li>'

    # Retournez les résultats au format JSON
    return JsonResponse({'results_html': results_html})




def chat(request):
    # Votre logique de vue pour la page de chat ici
    return render(request, 'chat/chat.html')  

