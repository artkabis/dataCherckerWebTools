from django.contrib import admin
from . models import *
from search_placeholder import ModelAdmin

class DatasRecordAdmin(ModelAdmin):
    title = 'Rechercher par site'  # Titre personnalisé pour le champ de recherche
    parameter_name = 'url_site'

    list_display = ('id', 'user_id', 'timestamp', 'name', 'email', 'url_site')
    list_filter = ('user_id', 'timestamp')
    search_fields = ['url_site']
    search_placeholder = 'Rechercher par site'


    

admin.site.register(DatasRecord, DatasRecordAdmin)
admin.site.register(Task)