from django.db import models
from django.contrib.auth.models import User

class Task(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    task = models.CharField(max_length=250)
    task_status = models.BooleanField(default=False)
    task_description = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        print("Mes tâches", self.task)
        return str(self.task)
    

class DatasRecord(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    timestamp = models.DateTimeField(auto_now_add=True)
    name = models.CharField(max_length=255)  # Ajoutez cette ligne pour la nouvelle colonne
    email = models.CharField(max_length=255)
    datas = models.JSONField()
    url_site = models.CharField(max_length=355)

    def __str__(self):
        print("Mes contrôles", self.url_site)
        return str(self.url_site)
    
class Message(models.Model):
    user = models.ForeignKey('auth.User', on_delete=models.CASCADE, related_name='task_messages')
    content = models.TextField()
    timestamp = models.DateTimeField(auto_now_add=True)

