from django.urls import path,include
from . import views

app_name = 'task'

urlpatterns = [
    path('', views.home, name='home'),
    path('register/', views.register, name='register'),
    path('login/', views.login, name='login'),
    path('logout/', views.logout_user, name='logout_user'),
    path('check-user/', views.check_user, name='check-user'),
    path('email-check', views.email_check, name='email-check'),
    path('add-todo', views.add_todo, name='add-todo'),
    path('mark-complete/<int:id>/', views.mark_complete, name='mark-complete'),
    path('delete-todo/<int:id>/', views.delete_todo, name='delete-todo'),
    path('datasCheck/', views.datasCheck, name='datasCheck'),
    path('ajax_search/', views.ajax_search, name='ajax_search'),
    path('chat/', views.chat, name='chat'), 
]
