(function($) {
    $(document).ready(function() {
        // Ciblez l'élément de recherche par son attribut name
        var searchInput = $('input[name=q]');

        // Modifiez le placeholder
        searchInput.attr('placeholder', 'Rechercher par site');

        // Vous pouvez également personnaliser d'autres attributs ou styles ici si nécessaire
    });
})(django.jQuery);